input_spreads.txt has the following data:

col 0: graphlet nr
col 1: avg hsa-meta sf
col 2: dev hsa-meta sf
col 3: avg hsa-meta sticky
col 4: dev hsa-meta sticky

