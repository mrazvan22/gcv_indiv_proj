#ifndef NCOUNT_NEW_GDV_H
#define NCOUNT_NEW_GDV_H

double* calc_avg_from_file(char* filename);


#endif

