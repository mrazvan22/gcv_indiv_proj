library(foreign)
w <- lookup.xport('
