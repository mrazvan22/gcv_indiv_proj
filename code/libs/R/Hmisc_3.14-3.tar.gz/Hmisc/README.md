Hmisc
=====

Harrell Miscellaneous

Current Goals
=============
* Continue to refine the summaryX class of functions that replace tables with graphics
   * See also bpplotM and tabulr
* See http://biostat.mc.vanderbilt.edu/HmiscNew

Web Sites
=============
* Overall: http://biostat.mc.vanderbilt.edu/Hmisc
* CRAN: http://cran.r-project.org/web/packages/Hmisc
* Changelog: https://github.com/harrelfe/Hmisc/commits/master
