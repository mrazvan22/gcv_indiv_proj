#!/bin/sh

DATADIR="${DATADIR-"${GCDIR-.}/data"}"

if [ $# -lt 1 ]; then echo "Specify dir"; exit 1; fi

echo "$DATADIR/$1/$1"

for m in "`ls "$DATADIR/$1/"`"; do
  if [ ! -d "$m" ]; then continue; fi
  mdir="$dir/$m"

  for i in "`ls "$mdir"`"; do
    echo "$mdir/$i"
  done
done
