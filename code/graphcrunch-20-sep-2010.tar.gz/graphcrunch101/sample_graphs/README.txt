bork2455 - high confidence yeast protein interactions by von Mering et al
shen-orr - Transcriptional regulation network of E. coli by Shen-Orr et al
           (Nature 2002) from http://www.weizmann.ac.il/mcb/UriAlon/
